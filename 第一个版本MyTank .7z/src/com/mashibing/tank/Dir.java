package com.mashibing.tank;

public enum Dir {
    L,U,R,D
}
